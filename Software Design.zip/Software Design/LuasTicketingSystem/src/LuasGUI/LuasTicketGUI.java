
package LuasGUI;

import LuasUpgrade.BlueRouteTicket;
import LuasUpgrade.EntertainmentUpgrade;
import LuasUpgrade.FirstClassUpgrade;
import LuasUpgrade.GreenRouteTicket;
import LuasUpgrade.NewspaperUpgrade;
import LuasUpgrade.RedRouteTicket;
import LuasUpgrade.RefreshmentUpgrade;
import LuasUpgrade.LuasTicketRoute;
import LuasUpgrade.WifiUpgrade;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.Border;


public class LuasTicketGUI extends JPanel implements MouseListener
{

    
    private JButton btnClear;
    private JButton btnTotalCost;
    private JButton btnRedRoute;
    private JButton btnBlueRoute;
    private JButton btnGreenRoute;

  
    private JPanel panelButtons;
    private JPanel panelDisplay;

   
    private final JTextField[] displayLabelRedRoute = new JTextField[1];
    private final JTextField[] displayLabelBlueRoute = new JTextField[1];
    private final JTextField[] displayLabelGreenRoute = new JTextField[1];

   
    private LuasTicketRoute redRouteList;
    private LuasTicketRoute blueRouteList;
    private LuasTicketRoute greenRouteList;

   
    private LuasTicketRoute redRouteFirstClass;
    private LuasTicketRoute redRouteEntertainment;
    private LuasTicketRoute redRouteWifi;
    private LuasTicketRoute redRouteRefreshment;
    private LuasTicketRoute redRouteRefreshment2;
    private LuasTicketRoute redRouteNewspaper;
    private LuasTicketRoute redRouteNewspaper2;

    
    private LuasTicketRoute blueRouteFirstClass;
    private LuasTicketRoute blueRouteEntertainment;
    private LuasTicketRoute blueRouteWifi;
    private LuasTicketRoute blueRouteRefreshment;
    private LuasTicketRoute blueRouteRefreshment2;
    private LuasTicketRoute blueRouteNewspaper;
    private LuasTicketRoute blueRouteNewspaper2;

    
    private LuasTicketRoute greenRouteFirstClass;
    private LuasTicketRoute greenRouteEntertainment;
    private LuasTicketRoute greenRouteWifi;
    private LuasTicketRoute greenRouteRefreshment;
    private LuasTicketRoute greenRouteRefreshment2;
    private LuasTicketRoute greenRouteNewspaper;
    private LuasTicketRoute greenRouteNewspaper2;

    
    private static double totalCost;

    LuasTicketGUI()
    {
        
        createPanels();

        
        createLabels();

        
        createButtons();

        
        addPanels();
        addButtons();
    }

  
    public final void createPanels()
    {
        this.setLayout(new BorderLayout());

        
        Dimension buttonPanelSize = new Dimension(250, 170);
        panelButtons = new JPanel();
        panelButtons.setLayout(new GridLayout(1, 4));
        panelButtons.setPreferredSize(buttonPanelSize);

        
        panelDisplay = new JPanel();
        panelDisplay.setLayout(new GridLayout(3, 1));
        panelDisplay.setPreferredSize(new Dimension(1400, 450));

    }

    
    public final void createLabels()
    {
        Font font = new Font("Arial", Font.PLAIN, 18);
       
        for (int i = 0; i < displayLabelRedRoute.length; i++)
        {
         
            displayLabelRedRoute[i] = new JTextField();
            displayLabelRedRoute[i].setBackground(new Color(255, 77, 77));
            displayLabelRedRoute[i].setFont(font);
            displayLabelRedRoute[i].setHorizontalAlignment(JLabel.CENTER);
            displayLabelRedRoute[i].setForeground(new Color(255, 255, 255, 255));
            displayLabelRedRoute[i].setEditable(false);
            displayLabelRedRoute[i].setOpaque(true);
            displayLabelRedRoute[i].addMouseListener(this);
            panelDisplay.add(displayLabelRedRoute[i]);
        }

  
        for (int i = 0; i < displayLabelBlueRoute.length; i++)
        {
           
            displayLabelBlueRoute[i] = new JTextField();
            displayLabelBlueRoute[i].setBackground(new Color(0, 153, 255));
            displayLabelBlueRoute[i].setFont(font);
            displayLabelBlueRoute[i].setHorizontalAlignment(JLabel.CENTER);
            displayLabelBlueRoute[i].setForeground(new Color(255, 255, 255, 255));
            displayLabelBlueRoute[i].setEditable(false);
            displayLabelBlueRoute[i].setOpaque(true);
            displayLabelBlueRoute[i].addMouseListener(this);
            panelDisplay.add(displayLabelBlueRoute[i]);
        }

        
        for (int i = 0; i < displayLabelGreenRoute.length; i++)
        {
           
            displayLabelGreenRoute[i] = new JTextField();
            displayLabelGreenRoute[i].setBackground(new Color(111, 220, 111));
            displayLabelGreenRoute[i].setFont(font);
            displayLabelGreenRoute[i].setHorizontalAlignment(JLabel.CENTER);
            displayLabelGreenRoute[i].setForeground(new Color(255, 255, 255, 255));
            displayLabelGreenRoute[i].setEditable(false);
            displayLabelGreenRoute[i].setOpaque(true);
            displayLabelGreenRoute[i].addMouseListener(this);
            panelDisplay.add(displayLabelGreenRoute[i]);
        }
    }

    
    public final void createButtons()
    {

        
        Color btn = new Color(64, 64, 64);
        Color text = new Color(153, 0, 77);
        Font font = new Font("Arial", Font.PLAIN, 30);
        Border whiteLine = BorderFactory.createLineBorder(Color.white);

      
        btnRedRoute = new JButton("Red Route Ticket");
        btnRedRoute.setBackground(new Color(154, 205, 50));
        btnRedRoute.setForeground(text);
        btnRedRoute.setFont(font);
        btnRedRoute.setFocusPainted(false);
        btnRedRoute.setBorder(whiteLine);
      
        btnRedRoute.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                for (int i = 0; i < displayLabelRedRoute.length; i++)
                {
                    if (displayLabelRedRoute[i].getText().isEmpty())
                    {

                        
                        LocalTime time = getTimeEntered();

                        
                        LocalDate date = getDateEntered();

                        
                        int option = optDialogOptionPassengerType("Choose a Ticket Type", "Select any Option");
                    
                        option = validateOptionPressedPassengerType(option);

                        if (option >= 0 && option <= 3)
                        {
                            if (option == 0)
                            {
                                redRouteList = new RedRouteTicket("Under 5", time, date);
                            } else if (option == 1)
                            {
                                redRouteList = new RedRouteTicket("Under 18", time, date);
                            } else if (option == 2)
                            {
                                redRouteList = new RedRouteTicket("Adult", time, date);
                            } else if (option == 3)
                            {
                                redRouteList = new RedRouteTicket("Pensioner", time, date);
                            }

                           
                            displayLabelRedRoute[i].setText(redRouteList.toString());
                            updateTotalCostRedRouteAdd();
                            break;

                        } else
                        {
                            cancelMessage();
                        }
                      
                    } else if (!displayLabelRedRoute[0].getText().isEmpty())
                    {
                        messageDialogBox("Booking is Full! Cannot Purchase Another Red Ticket");
                        break;
                    }
                }
            }
        });

        
        btnBlueRoute = new JButton("Blue Route Ticket");
        btnBlueRoute.setBackground(Color.DARK_GRAY);
        btnBlueRoute.setForeground(text);
        btnBlueRoute.setFont(font);
        btnBlueRoute.setFocusPainted(false);
        btnBlueRoute.setBorder(whiteLine);
    
        btnBlueRoute.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                for (int i = 0; i < displayLabelBlueRoute.length; i++)
                {
                   
                    if (displayLabelBlueRoute[i].getText().isEmpty())
                    {
                        
                        LocalTime time = getTimeEntered();
                     
                        LocalDate date = getDateEntered();

                       
                        int option = optDialogOptionPassengerType("Choose a Ticket Type", "Select any Option");
                        
                        option = validateOptionPressedPassengerType(option);

                        if (option >= 0 && option <= 3)
                        {
                            if (option == 0)
                            {
                                blueRouteList = new BlueRouteTicket("Under 5", time, date);
                            } else if (option == 1)
                            {
                                blueRouteList = new BlueRouteTicket("Under 18", time, date);
                            } else if (option == 2)
                            {
                                blueRouteList = new BlueRouteTicket("Adult", time, date);
                            } else if (option == 3)
                            {
                                blueRouteList = new BlueRouteTicket("Pensioner", time, date);
                            }

                          
                            displayLabelBlueRoute[i].setText(blueRouteList.toString());
                            updateTotalCostBlueRouteAdd();
                            break;

                        } else
                        {
                            cancelMessage();
                        }
                  
                    } else if (!displayLabelBlueRoute[0].getText().isEmpty())
                    {
                        messageDialogBox("Booking is Full! Cannot Purchase Another Blue Ticket");
                        break;
                    }
                }
            }
        });

      
        btnGreenRoute = new JButton("Green Route Ticket");
        btnGreenRoute.setBackground(Color.DARK_GRAY);
        btnGreenRoute.setForeground(text);
        btnGreenRoute.setFont(font);
        btnGreenRoute.setFocusPainted(false);
        btnGreenRoute.setBorder(whiteLine);
       
        btnGreenRoute.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                for (int i = 0; i < displayLabelGreenRoute.length; i++)
                {
                    if (displayLabelGreenRoute[i].getText().isEmpty())
                    {
                      
                        LocalTime time = getTimeEntered();
                        
                        LocalDate date = getDateEntered();

                        int option = optDialogOptionPassengerType("Choose a Ticket Type", "Select any Option");
                        option = validateOptionPressedPassengerType(option);

                        if (option >= 0 && option <= 3)
                        {
                            if (option == 0)
                            {
                                greenRouteList = new GreenRouteTicket("Under 5", time, date);
                            } else if (option == 1)
                            {
                                greenRouteList = new GreenRouteTicket("Under 18", time, date);
                            } else if (option == 2)
                            {
                                greenRouteList = new GreenRouteTicket("Adult", time, date);
                            } else if (option == 3)
                            {
                                greenRouteList = new GreenRouteTicket("Pensioner", time, date);
                            }
                           
                            displayLabelGreenRoute[i].setText(greenRouteList.toString());
                            updateTotalCostGreenRouteAdd();
                            break;

                        } else
                        {
                            cancelMessage();
                        }
                        
                    } else if (!displayLabelGreenRoute[0].getText().isEmpty())
                    {
                        messageDialogBox("Booking is Full! Cannot Purchase Another Green Ticket");
                        break;
                    }
                }
            }
        });

       
        btnTotalCost = new JButton("Total Cost");
        btnTotalCost.setBackground(Color.DARK_GRAY);
        btnTotalCost.setForeground(text);
        btnTotalCost.setFont(font);
        btnTotalCost.setFocusPainted(false);
        btnTotalCost.setBorder(whiteLine);
        btnTotalCost.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
               
                int opts = optDialogOption("Do you want to view Current Total", "Please Select any Option");

           
                if (opts == 0)
                {
                    messageDialogBox("Total Is: Euro" + totalCost);
                } 
                else if (opts == 1)
                {
                    cancelMessage();
                }
            }
        });

       
        btnClear = new JButton("Clear App");
        btnClear.setBackground(Color.DARK_GRAY);
        btnClear.setForeground(text);
        btnClear.setFont(font);
        btnClear.setFocusPainted(false);
        btnClear.setBorder(whiteLine);
        btnClear.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ex)
            {
                int clearApp = optDialogOption("Do you want the Application to be Cleared", "Please Select any Option");

                if (clearApp == 0)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        redRouteList = null;
                        redRouteFirstClass = null;
                        redRouteEntertainment = null;
                        redRouteWifi = null;
                        redRouteNewspaper = null;
                        redRouteRefreshment = null;
                        redRouteNewspaper2 = null;
                        redRouteRefreshment2 = null;

                        blueRouteList = null;
                        blueRouteFirstClass = null;
                        blueRouteEntertainment = null;
                        blueRouteWifi = null;
                        blueRouteNewspaper = null;
                        blueRouteRefreshment = null;
                        blueRouteNewspaper2 = null;
                        blueRouteRefreshment2 = null;

                        greenRouteList = null;
                        greenRouteFirstClass = null;
                        greenRouteEntertainment = null;
                        greenRouteWifi = null;
                        greenRouteNewspaper = null;
                        greenRouteRefreshment = null;

                        displayLabelRedRoute[i].setText(null);
                        displayLabelBlueRoute[i].setText(null);
                        displayLabelGreenRoute[i].setText(null);

                    }
                    totalCost = 0;
                    messageDialogBox("Successfully Cleared Application");
                } else
                {
                    cancelMessage();
                }
            }
        });
    }

    
    public final void addButtons()
    {
        panelButtons.add(btnRedRoute);
        panelButtons.add(btnBlueRoute);
        panelButtons.add(btnGreenRoute);
        panelButtons.add(btnTotalCost);
        panelButtons.add(btnClear);
    }

    
    public final void addPanels()
    {
        this.add(panelButtons, BorderLayout.SOUTH);
        this.add(panelDisplay, BorderLayout.CENTER);
    }

    
    public void updateTotalCostRedRouteAdd()
    {
      
        if (redRouteList == null)
        {
            return;
        } else
        {
            
            totalCost += redRouteList.getCost();
        }
    }

    
    public void updateTotalCostRedRouteMinus()
    {
        if (redRouteList == null)
        {
            return;
        } else
        {
            totalCost -= redRouteList.getCost();
        }
    }

    
    public void updateTotalCostBlueRouteAdd()
    {
        if (blueRouteList == null)
        {
            return;
        } else
        {
            
            totalCost += blueRouteList.getCost();
        }
    }

    
    public void updateTotalCostBlueRouteMinus()
    {
        if (blueRouteList == null)
        {
            System.out.print("");
        } else
        {
            totalCost -= blueRouteList.getCost();
        }
    }

    
    public void updateTotalCostGreenRouteAdd()
    {
        if (greenRouteList == null)
        {
            System.out.println("");
        } else
        {
            totalCost += greenRouteList.getCost();
        }
    }

   
    public void updateTotalCostGreenRouteMinus()
    {
        if (greenRouteList == null)
        {
            System.out.println("");
        } else
        {
            totalCost -= greenRouteList.getCost();
        }
    }

    
    public void displayRedRouteText()
    {
        for (int i = 0; i < displayLabelRedRoute.length; i++)
        {
            displayLabelRedRoute[i].setText(redRouteList.toString());
        }
    }

    
    public void displayBlueRouteText()
    {
        for (int i = 0; i < displayLabelBlueRoute.length; i++)
        {
            displayLabelBlueRoute[i].setText(blueRouteList.toString());
        }
    }

    
    public void displayGreenRouteText()
    {
        for (int i = 0; i < displayLabelGreenRoute.length; i++)
        {
            displayLabelGreenRoute[i].setText(greenRouteList.toString());
        }
    }

    @Override
    public void mouseClicked(MouseEvent e)
    {
        
    }

    
    @Override
    public void mousePressed(MouseEvent me)
    {
        if (SwingUtilities.isLeftMouseButton(me))
        {
            for (int i = 0; i < displayLabelRedRoute.length; i++)
            {
                if (me.getSource() == displayLabelRedRoute[i])
                {
                    if (!displayLabelRedRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOptionUpgrade("Choose an Upgrade", "Please Select any Option");

                        if (me.getSource() == displayLabelRedRoute[i])
                        {
                           
                            if (upgradeOption == 0)
                            {
                                
                                if (redRouteFirstClass != null)
                                {
                                    messageDialogBox("Cannot add First Class Upgrade again");
                                    break;
                                }

                               
                                updateTotalCostRedRouteMinus();
                                redRouteList = new FirstClassUpgrade(redRouteList);
                                

                               
                            } else if (upgradeOption == 1)
                            {
                                
                                if (redRouteEntertainment != null)
                                {
                                    messageDialogBox("Cannot add Entertainment Upgrade again");
                                    break;
                                }

                                
                                updateTotalCostRedRouteMinus();
                                redRouteList = new EntertainmentUpgrade(redRouteList);
                                

                             
                            } else if (upgradeOption == 2)
                            {
                               
                                if (redRouteNewspaper == null)
                                {
                                    updateTotalCostRedRouteMinus();
                                    redRouteNewspaper = new NewspaperUpgrade(redRouteList);
                                    redRouteList = redRouteNewspaper;

                                   
                                } else if (redRouteNewspaper != null && redRouteNewspaper2 == null)
                                {
                                    updateTotalCostRedRouteMinus();
                                    redRouteNewspaper2 = new NewspaperUpgrade(redRouteList);
                                    redRouteList = redRouteNewspaper2;

                                   
                                } else
                                {
                                    messageDialogBox("Cannot add Newspaper Upgrade again");
                                    break;
                                }

                               
                            } else if (upgradeOption == 3)
                            {
                                
                                if (redRouteRefreshment == null)
                                {
                                    updateTotalCostRedRouteMinus();
                                    redRouteRefreshment = new RefreshmentUpgrade(redRouteList);
                                    redRouteList = redRouteRefreshment;

                              
                                } else if (redRouteRefreshment != null && redRouteRefreshment2 == null)
                                {
                                    updateTotalCostRedRouteMinus();
                                    redRouteRefreshment2 = new RefreshmentUpgrade(redRouteList);
                                    redRouteList = redRouteRefreshment2;

                                  
                                } else
                                {
                                    messageDialogBox("Cannot add Refreshment Upgrade again");
                                    break;
                                }

                                
                            } else if (upgradeOption == 4)
                            {
                               
                                if (redRouteWifi != null)
                                {
                                    messageDialogBox("Cannot add WiFi Upgrade again");
                                    break;
                                }

                              
                                updateTotalCostRedRouteMinus();
                                redRouteWifi = new WifiUpgrade(redRouteList);
                                redRouteList = redRouteWifi;

                            } else
                            {
                                cancelMessage();
                            }

                            updateTotalCostRedRouteAdd();
                            displayRedRouteText();
                            break;
                        }
                        
                    } else if (displayLabelRedRoute[i].getText().isEmpty())
                    {
                        messageDialogBox("The Red Ticket is Empty");
                        break;
                    }
                }
            }

            for (int i = 0; i < displayLabelBlueRoute.length; i++)
            {
                if (me.getSource() == displayLabelBlueRoute[i])
                {
                    if (!displayLabelBlueRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOptionUpgrade("Choose an Upgrade", "Please Select any Option");
                        if (me.getSource() == displayLabelBlueRoute[i])
                        {
                           
                            if (upgradeOption == 0)
                            {
                                if (blueRouteFirstClass != null)
                                {
                                    messageDialogBox("Cannot add First Class Upgrade again");
                                    break;
                                }

                                updateTotalCostBlueRouteMinus();
                                blueRouteFirstClass = new FirstClassUpgrade(blueRouteList);
                                blueRouteList = blueRouteFirstClass;

                               
                            } else if (upgradeOption == 1)
                            {
                                if (blueRouteEntertainment != null)
                                {
                                    messageDialogBox("Cannot add Entertainment Upgrade again");
                                    break;
                                }

                                updateTotalCostBlueRouteAdd();
                                blueRouteEntertainment = new EntertainmentUpgrade(blueRouteList);
                                blueRouteList = blueRouteEntertainment;

                              
                            } else if (upgradeOption == 2)
                            {
                                if (blueRouteNewspaper == null)
                                {
                                    updateTotalCostBlueRouteMinus();
                                    blueRouteNewspaper = new NewspaperUpgrade(blueRouteList);
                                    blueRouteList = blueRouteNewspaper;
                                } else if (blueRouteNewspaper != null && blueRouteNewspaper2 == null)
                                {
                                    updateTotalCostBlueRouteMinus();
                                    blueRouteNewspaper2 = new NewspaperUpgrade(blueRouteList);
                                    blueRouteList = blueRouteNewspaper2;
                                } else
                                {
                                    messageDialogBox("Cannot add Newspaper Upgrade again");
                                    break;
                                }

                               
                            } else if (upgradeOption == 3)
                            {
                                if (blueRouteRefreshment == null)
                                {
                                    updateTotalCostBlueRouteMinus();
                                    blueRouteRefreshment = new RefreshmentUpgrade(blueRouteList);
                                    blueRouteList = blueRouteRefreshment;
                                } else if (blueRouteRefreshment != null && blueRouteRefreshment2 == null)
                                {
                                    updateTotalCostBlueRouteMinus();
                                    blueRouteRefreshment2 = new RefreshmentUpgrade(blueRouteList);
                                    blueRouteList = blueRouteRefreshment2;
                                } else
                                {
                                    messageDialogBox("Cannot add Refreshment Upgrade again");
                                    break;
                                }

                           
                            } else if (upgradeOption == 4)
                            {
                                if (blueRouteWifi != null)
                                {
                                    messageDialogBox("Cannot add WiFi Upgrade again");
                                }

                                updateTotalCostBlueRouteMinus();
                                blueRouteWifi = new WifiUpgrade(blueRouteList);
                                blueRouteList = blueRouteWifi;

                               
                            } else
                            {
                                cancelMessage();
                            }

                            updateTotalCostBlueRouteAdd();
                            displayBlueRouteText();
                            break;
                        }
                    } else if (displayLabelBlueRoute[i].getText().isEmpty())
                    {
                        messageDialogBox("The Blue Ticket is Empty");
                        break;
                    }
                }
            }

            for (int i = 0; i < displayLabelGreenRoute.length; i++)
            {
                if (me.getSource() == displayLabelGreenRoute[i])
                {
                    if (!displayLabelGreenRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOptionUpgrade("Choose an Upgrade", "Please Select any Option");

                        if (me.getSource() == displayLabelGreenRoute[i])
                        {
                          
                            if (upgradeOption == 0)
                            {
                                if (greenRouteFirstClass != null)
                                {
                                    messageDialogBox("Cannot add First Class Upgrade again");
                                }

                                updateTotalCostGreenRouteMinus();
                                greenRouteFirstClass = new FirstClassUpgrade(greenRouteList);
                                greenRouteList = greenRouteFirstClass;

                            } else if (upgradeOption == 1)
                            {
                                if (greenRouteEntertainment != null)
                                {
                                    messageDialogBox("Cannot add Entertainment Upgrade again");
                                }

                                updateTotalCostGreenRouteMinus();
                                greenRouteEntertainment = new EntertainmentUpgrade(greenRouteList);
                                greenRouteList = greenRouteEntertainment;

                                
                            } else if (upgradeOption == 2)
                            {
                                if (greenRouteNewspaper == null)
                                {
                                    updateTotalCostGreenRouteMinus();
                                    greenRouteNewspaper = new NewspaperUpgrade(greenRouteList);
                                    greenRouteList = greenRouteNewspaper;
                                } else if (greenRouteNewspaper != null && greenRouteNewspaper2 == null)
                                {
                                    updateTotalCostGreenRouteMinus();
                                    greenRouteNewspaper2 = new NewspaperUpgrade(greenRouteList);
                                    greenRouteList = greenRouteNewspaper2;
                                } else
                                {
                                    messageDialogBox("Cannot add Newspaper Upgrade again");
                                }
                                
                            } else if (upgradeOption == 3)
                            {
                                if (greenRouteRefreshment == null)
                                {
                                    updateTotalCostGreenRouteMinus();
                                    greenRouteRefreshment = new RefreshmentUpgrade(greenRouteList);
                                    greenRouteList = greenRouteRefreshment;
                                } else if (greenRouteRefreshment != null && greenRouteRefreshment2 == null)
                                {
                                    updateTotalCostGreenRouteMinus();
                                    greenRouteRefreshment2 = new RefreshmentUpgrade(greenRouteList);
                                    greenRouteList = greenRouteRefreshment2;
                                } else
                                {
                                    messageDialogBox("Cannot add Refreshment Upgrade again");
                                }
                            } else if (upgradeOption == 4)
                            {
                                if (greenRouteWifi != null)
                                {
                                    messageDialogBox("Cannot add WiFi Upgrade again");
                                }

                                updateTotalCostGreenRouteMinus();
                                greenRouteWifi = new WifiUpgrade(greenRouteList);
                                greenRouteList = greenRouteWifi;
                            } else
                            {
                                cancelMessage();
                            }

                            updateTotalCostGreenRouteAdd();
                            displayGreenRouteText();
                            break;
                        }
                    } else if (displayLabelGreenRoute[i].getText().isEmpty())
                    {
                        messageDialogBox("The Green Ticket is Empty");
                        break;
                    }
                }
            }
            
        } else if (SwingUtilities.isRightMouseButton(me))
        {
            for (int i = 0; i < displayLabelRedRoute.length; i++)
            {
                if (me.getSource() == displayLabelRedRoute[i])
                {
                    if (!displayLabelRedRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOption("Do you want to remove the previous layer?", "Please Select any Option");

                        if (me.getSource() == displayLabelRedRoute[i])
                        {
                            redRouteList = redRouteList.getPreviousLayer();
                            totalCost = redRouteList.getCost();
                        }
                        displayRedRouteText();
                    }
                }
            }
            for (int i = 0; i < displayLabelBlueRoute.length; i++)
            {
                if (me.getSource() == displayLabelBlueRoute[i])
                {
                    if (!displayLabelBlueRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOptionUpgrade("Choose an Option To Remove", "Please Select any Option");
                        if (me.getSource() == displayLabelBlueRoute[i])
                        {
                            blueRouteList = blueRouteList.getPreviousLayer();
                            totalCost = blueRouteList.getCost();
                        }
                        displayBlueRouteText();
                    }
                }
            }

            for (int i = 0; i < displayLabelGreenRoute.length; i++)
            {
                if (me.getSource() == displayLabelGreenRoute[i])
                {
                    if (!displayLabelGreenRoute[i].getText().isEmpty())
                    {
                        int upgradeOption = optDialogOptionUpgrade("Choose an Option To Remove", "Please Select any Option");

                        if (me.getSource() == displayLabelGreenRoute[i])
                        {
                            greenRouteList = greenRouteList.getPreviousLayer();
                            totalCost = greenRouteList.getCost();
                        }
                        displayGreenRouteText();
                    }
                }
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e
    )
    {
    }

    @Override
    public void mouseEntered(MouseEvent e
    )
    {
    }

    @Override
    public void mouseExited(MouseEvent e
    )
    {
    }

    
    public void messageDialogBox(String message)
    {
        JOptionPane.showMessageDialog(null, message);
    }

    
    public int optDialogOptionPassengerType(String title, String message)
    {
        String[] options
                =
                {
                    "Under 5", "Under 18", "Adult", "Pensioner"
                };

        
        int varMessage = JOptionPane.showOptionDialog(null,
                title,
                message,
                JOptionPane.OK_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        return varMessage;
    }

    
    public int optDialogOptionUpgrade(String title, String message)
    {
        String[] options
                =
                {
                    "First Class", "Entertainment", "Newspaper", "Refreshment", "Wifi", "None"
                };

      
        int varMessage = JOptionPane.showOptionDialog(null,
                title,
                message,
                JOptionPane.OK_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        return varMessage;
    }

   
    public String optDialogOptionDepartureTime(String title, String message)
    {
        String[] times =
        {
            "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
            "11:00", "11:30", "12:00", "13:00", "14:00", "15:00", "16:00",
            "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "21:00"
        };
        JFrame frame = new JFrame("Input A Time");
        String time = (String) JOptionPane.showInputDialog(frame,
                title,
                message,
                JOptionPane.QUESTION_MESSAGE,
                null,
                times,
                times[0]);

        return time;
    }

    
    public int optDialogOption(String j, String k)
    {
        String[] opts
                =
                {
                    "Yes", "No"
                };

        int varOpt = JOptionPane.showOptionDialog(
                null,
                j,
                k,
                JOptionPane.OK_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opts,
                opts[0]);

        return varOpt;
    }

   
    public String optDialogInput(String i)
    {
        String var = JOptionPane.showInputDialog(i);
        return var;
    }

   
    public void cancelMessage()
    {
        messageDialogBox("Cancelled");
    }

   
    public LocalDate getDateEntered()
    {
        int x = 1;
        LocalDate date = null;
        String inputDate = optDialogInput("Please Enter A Valid Date yyyy-MM-dd");

        do
        {
            try
            {
                date = LocalDate.parse(inputDate, DateTimeFormatter.ISO_DATE);
                if (date.isBefore(LocalDate.now()))
                {
                    x = 1;
                    inputDate = optDialogInput("Please Re-enter A Valid Date yyyy-MM-dd");
                } else if (date.isAfter(LocalDate.now()) || date.isEqual(LocalDate.now()))
                {
                    x = 2;
                }
            } catch (Exception ex)
            {
                inputDate = optDialogInput("Please Re-enter A Valid Date yyyy-MM-dd");
            }
        } while (x == 1);

        return date;
    }

   
    public LocalTime getTimeEntered()
    {

        int x = 1;
        String departureOption = optDialogOptionDepartureTime("Choose a Departure Time", "Plese Select any Option");
        LocalTime time = null;
        do
        {
            try
            {
                time = LocalTime.parse(departureOption, DateTimeFormatter.ISO_LOCAL_TIME);
                x = 2;
            } catch (Exception exception)
            {
                departureOption = optDialogOptionDepartureTime("Re-Choose a Departure Time ", "Plese Select any Option");
            }
        } while (x == 1);

        return time;
    }

  
    public int validateOptionPressedPassengerType(int option)
    {
        while (option == JOptionPane.CLOSED_OPTION)
        {
            option = optDialogOptionPassengerType("Can't Press X Button, Choose a Ticket Type", "Please Select any Option");
        }

        return option;
    }
}
