
 
package LuasGUI;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;


public class TicketSystem
{

   
    public static void main(String args[])
    {
       
        JFrame frame = new JFrame();

        
        LuasTicketGUI panel = new LuasTicketGUI();
        frame.getContentPane().add(panel);
        
        JLabel lblNewLabel = new JLabel("    Luas Ticketing System - Please Select Your Route");
        lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 55));
        lblNewLabel.setBackground(Color.BLACK);
        panel.add(lblNewLabel, BorderLayout.NORTH);

       
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1800, 1000);
        frame.setResizable(true);
        frame.setVisible(true); 
    }
}
