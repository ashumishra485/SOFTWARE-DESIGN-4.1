

package LuasUpgrade;

import java.time.LocalDate;
import java.time.LocalTime;


public abstract class LuasTicketRoute
{

   
    protected double cost;

    protected String departureLocation;
    protected String arrivalLocation;
    protected LocalTime departureTime;

    protected LocalTime arrivalTime;

    
    protected LocalDate date;

    protected String passengerType;

 
    protected String upgrade = "";

  
    public abstract double getCost();

   
    public abstract String getDepartureLoaction();

 
    public abstract String getArrivalLoaction();

    
    public abstract LocalTime getDepartureTime();

    public abstract LocalTime getArrivalTime();

    
    public abstract LocalDate getDate();

   
    public abstract String getPassengerType();

   
    public abstract String getUpgrade();

   
    
    public abstract LuasTicketRoute getPreviousLayer();
    
    
    @Override
    public String toString()
    {
        return String.format(" \n Price: Euro %s,    Depart From: %s,    Arrive At: %s,   Depart Time: %s,   Arrive At: %s,   Date: %s,   Type: %s,   Extra's Code: %s",
                cost, departureLocation, arrivalLocation, departureTime, arrivalTime, date, passengerType, upgrade);
    }
}
