
package LuasUpgrade;


public class RefreshmentUpgrade extends LuasTicketUpgrade
{

    public RefreshmentUpgrade(LuasTicketRoute t)
    {
        super(t);
        cost = 2;
        upgrade = "R";
    }
}
