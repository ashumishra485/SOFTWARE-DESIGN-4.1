
package LuasUpgrade;


public class EntertainmentUpgrade extends LuasTicketUpgrade
{

    
    public EntertainmentUpgrade(LuasTicketRoute t)
    {
        super(t);
        cost = 100;
        upgrade = "E";
    }
}
