

package LuasUpgrade;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;


public abstract class LuasTicketUpgrade extends LuasTicketRoute
{

  
    protected LuasTicketRoute t;

    
    public LuasTicketUpgrade(LuasTicketRoute t)
    {
        this.t = t;
    }

    @Override
    public double getCost()
    {
        return t.getCost() + cost;
    }

   
    @Override
    public String getDepartureLoaction()
    {
        return t.getDepartureLoaction();
    }

   
    @Override
    public String getArrivalLoaction()
    {
        return t.getArrivalLoaction();
    }

   
    @Override
    public LocalTime getDepartureTime()
    {
        return t.getDepartureTime();
    }

   
    @Override
    public LocalTime getArrivalTime()
    {
        return t.getArrivalTime();
    }

   
    @Override
    public LocalDate getDate()
    {
        return t.getDate();
    }

   
    @Override
    public String getPassengerType()
    {
        return t.getPassengerType();
    }

  
    @Override
    public String getUpgrade()
    {
        return t.getUpgrade() + " " + upgrade;
    }
    
   
    public LuasTicketRoute getPreviousLayer()
    {
        return t;
    }
    

    @Override
    public String toString()
    {
        return String.format(" \n Price: Euro%s,    Depart From: %s,    Arrive At: %s,   Depart Time: %s,   Arrive At: %s,   Date: %s,   Type: %s,   Extra's Code: %s",
                getCost(), getDepartureLoaction(), getArrivalLoaction(), getDepartureTime(),
                getArrivalTime(), getDate(), getPassengerType(), getUpgrade());
    }
}
