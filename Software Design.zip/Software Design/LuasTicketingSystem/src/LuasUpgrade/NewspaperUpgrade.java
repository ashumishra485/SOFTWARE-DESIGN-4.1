

package LuasUpgrade;


public class NewspaperUpgrade extends LuasTicketUpgrade
{

    
    public NewspaperUpgrade(LuasTicketRoute t)
    {
        super(t);
        cost = 2;
        upgrade = "N";
    }
}
