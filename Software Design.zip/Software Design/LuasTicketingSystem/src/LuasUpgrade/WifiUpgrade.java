

package LuasUpgrade;


public class WifiUpgrade extends LuasTicketUpgrade
{

   
    public WifiUpgrade(LuasTicketRoute t)
    {
        super(t);
        cost = 10;
        upgrade = "W";
    }
}
