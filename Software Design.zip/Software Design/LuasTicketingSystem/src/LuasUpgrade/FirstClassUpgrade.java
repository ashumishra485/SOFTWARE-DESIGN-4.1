
 

 

package LuasUpgrade;


public class FirstClassUpgrade extends LuasTicketUpgrade
{
    
    public FirstClassUpgrade(LuasTicketRoute t)
    {
        super(t);
        cost = 217;
        upgrade = "FC";
        t.getUpgrade();
        System.out.println(t.upgrade);
    }
}
