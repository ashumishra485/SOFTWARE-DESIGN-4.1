
package LuasUpgrade;

import java.time.LocalTime;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;


public class RedRouteTicket extends LuasTicketRoute
{

    
    RedRouteTicket()
    {
        passengerType = "";
        departureTime = LocalTime.of(0, 0);
        date = LocalDate.of(0, 1, 1);
    }

   
    public RedRouteTicket(String passengerType, LocalTime departureTime, LocalDate date)
    {
        departureLocation = "The Point";
        arrivalLocation = "Tallaght";
        this.passengerType = passengerType;
        this.departureTime = departureTime;
        arrivalTime = departureTime.plusHours(1);
        this.date = date;

        calcCharge();
    }

   
    public final void calcCharge()
    {
      
        switch (passengerType)
        {
            case "Under 5":
                cost = 0.0;
                break;
            case "Under 18":
                cost = 5.0;
                break;
            case "Adult":
                cost = 10.0;
                break;
            case "Pensioner":
                cost = 5.0;
                break;
            default:
                cost = -1;
                break;
        }

        
        if (this.date.getDayOfWeek() == this.date.getDayOfWeek().SATURDAY || this.date.getDayOfWeek() == this.date.getDayOfWeek().SUNDAY)
        {
            cost = cost + 2.0;
        }

      
        if (this.departureTime.isAfter(LocalTime.of(8, 29)) && this.departureTime.isBefore(LocalTime.of(11, 31)))
        {
            cost = cost + 2.0;
        } else if (this.departureTime.isAfter(LocalTime.of(15, 59)) && this.departureTime.isBefore(LocalTime.of(18, 31)))
        {
            cost = cost + 4.0;
        }
    }

  
    @Override
    public double getCost()
    {
        return cost;
    }

    @Override
    public String getDepartureLoaction()
    {
        return departureLocation;
    }

    
    @Override
    public String getArrivalLoaction()
    {
        return arrivalLocation;
    }

   
    @Override
    public LocalTime getDepartureTime()
    {
        return departureTime;
    }

   
    @Override
    public LocalTime getArrivalTime()
    {
        return arrivalTime;
    }

  
    @Override
    public LocalDate getDate()
    {
        return date;
    }

   
    @Override
    public String getPassengerType()
    {
        return passengerType;
    }

    
    @Override
    public String getUpgrade()
    {
        return upgrade;
    }
    
    @Override
    public LuasTicketRoute getPreviousLayer()
    {
        return this;
    }
}
