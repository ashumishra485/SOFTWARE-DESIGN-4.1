
package com.dt.project.gui.client;

import com.dt.project.api.LuckyNumber;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

import javax.print.DocFlavor.STRING;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Registry registry = LocateRegistry.getRegistry("localhost", 6789);
        ArrayList<String> data = new ArrayList<>();
        
        LuckyNumber luckyNumber = (LuckyNumber) registry.lookup("lucky");
        
        VBox root = new VBox(5);
        Label lblNumber = new Label("Guess the Lucky Number");
        TextField txtNumber = new TextField();
        Button btnProcess = new Button("Process");
        Button btnchances = new Button("Show History");
        Label lblResponse = new Label();
        
        btnProcess.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
                try {
                	data.add(txtNumber.getText());
                    String response = luckyNumber.process(txtNumber.getText());
                    lblResponse.setText(response);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        
        btnchances.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent t) {
				System.out.println("Output are");
               for (String integer : data) {
				System.out.println(integer);
			}
            }
        });
        
        root.getChildren().addAll(lblNumber, txtNumber, btnProcess, lblResponse,btnchances);
        
        stage.setScene(new Scene(root, 300, 200));
        
        stage.setTitle("RMI GUI Client App");
        
        stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
